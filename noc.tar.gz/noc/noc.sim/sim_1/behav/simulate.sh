#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xsim noc_3x3_wrapper_behav -key {Behavioral:sim_1:Functional:noc_3x3_wrapper} -tclbatch noc_3x3_wrapper.tcl -log simulate.log
