#!/bin/bash -f
xv_path="/opt/Xilinx/Vivado/2016.2"
ExecStep()
{
"$@"
RETVAL=$?
if [ $RETVAL -ne 0 ]
then
exit $RETVAL
fi
}
ExecStep $xv_path/bin/xelab -wto e3773040ce9c47beb5cd82be558432d6 -m64 --debug typical --relax --mt 8 -L xil_defaultlib -L xpm -L blk_mem_gen_v8_3_3 -L axi_bram_ctrl_v4_0_8 -L generic_baseblocks_v2_1_0 -L axi_infrastructure_v1_1_0 -L axi_register_slice_v2_1_9 -L fifo_generator_v13_1_1 -L axi_data_fifo_v2_1_8 -L axi_crossbar_v2_1_10 -L dist_mem_gen_v8_0_10 -L lib_bmg_v1_0_5 -L lib_cdc_v1_0_2 -L axi_traffic_gen_v2_0_10 -L unisims_ver -L unimacro_ver -L secureip --snapshot noc_3x3_wrapper_behav xil_defaultlib.noc_3x3_wrapper xil_defaultlib.glbl -log elaborate.log
